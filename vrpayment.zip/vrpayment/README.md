# PrestaShop 9 VR Payment Integration
This repository contains the PrestaShop VR Payment payment module that enables the shop to process payments with [VR Payment](https://www.vr-payment.de).

To install module manually by dragging up zip file, please download [.zip archive](@WalleeDocPath(/vrpayment.zip)) of module with correct structure required by Prestashop installation

##### To use this extension, a [VR Payment](https://gateway.vr-payment.de/user/login) account is required.

## Requirements

* [PrestaShop](https://www.prestashop.com/) 9
* [PHP](http://php.net/) 9.0 (minimum PHP version supported by Prestashop 9 version)

## Documentation

* [English](@WalleeDocPath(/docs/en/documentation.html))

## Support

Support queries can be issued on the [VR Payment support site](https://www.vr-payment.de/hotline).

## Supported versions

____________________________________________________________________________
| Prestashop version | Plugin major version | Supported until        |
|--------------------|----------------------|------------------------|
| 9.0.x - 9.1.x      | 2.x                  | Further notice         |
| 8.0.x - 8.2.x      | 1.x                  | Further notice         |
----------------------------------------------------------------------------

## License

Please see the [license file](@WalleeRepoPath(/LICENSE)) for more information.

## Other PrestaShop Versions

Find the module for different PrestaShop versions [here](../../../prestashop).
